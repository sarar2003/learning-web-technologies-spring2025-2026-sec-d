<?php
session_start();
$isAjax = true;


if(isset($_POST['submit'])){
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $email = $_POST['email'] ?? '';

    if($username === '' || $password === '' || $email === ''){
        $response = ['success' => false, 'message' => 'Null username/password/email!'];
    } else {
        require_once '../model/UserModel.php';
        $userModel = new UserModel();
        if ($userModel->create($username, $password, $email)) {
            $_SESSION['username'] = $username;
            setcookie('status', true, time() + 3000, '/');
            $response = ['success' => true, 'message' => 'User created successfully', 'redirect' => '../view/user_list.php'];
        } else {
            $response = ['success' => false, 'message' => 'Signup failed'];
        }

    }
    
    if($isAjax){
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    } else {
        if($response['success']){
            header('location: ' . $response['redirect']);
        } else {
            echo $response['message'];
        }
    }
} else {
    $response = ['success' => false, 'message' => 'Invalid request! Please submit form'];
    if($isAjax){
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    } else {
        echo $response['message'];
    }
}

?>
