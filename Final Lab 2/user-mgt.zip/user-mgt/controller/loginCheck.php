<?php
session_start();
$isAjax = true;


if(isset($_POST['submit'])){
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if($username === '' || $password === ''){
        $response = ['success' => false, 'message' => 'Null username/password!'];
    } else {
        require_once '../model/UserModel.php';
        $userModel = new UserModel();
        $user = $userModel->findByUsernamePassword($username, $password);
        if ($user) {
            $_SESSION['username'] = $username;
            setcookie('status', true, time() + 3000, '/');
            $response = ['success' => true, 'message' => 'Login successful', 'redirect' => '../view/home.php'];
        } else {
            $response = ['success' => false, 'message' => 'Invalid user!'];
        }

    }
    
    if($isAjax){
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    } else {
        if($response['success'] ?? false){
            header('location: ' . ($response['redirect'] ?? '../view/home.php'));
        } else {
            echo $response['message'];
        }
    }
} else {
    $response = ['success' => false, 'message' => 'Invalid request! Please submit form'];
    if($isAjax){
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    } else {
        echo $response['message'];
    }
}

?>
