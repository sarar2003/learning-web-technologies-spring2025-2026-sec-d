<?php
$host = 'localhost';
$port = '3306';
$dbname = 'webtech_users';
$username = 'root';
$password = '';

$conn = mysqli_connect($host, $username, $password, $dbname, $port);

if (!$conn) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'DB Connection failed: ' . mysqli_connect_error()]);
    exit;
}
$GLOBALS['conn'] = $conn;


function closeConn($conn) {
    mysqli_close($conn);
}
?>

