# MySQL Migration Plan

## Info

- Use model/ for DB files.
- Assume XAMPP: root/blank, DB 'webtech_users'.

## Steps

- [ ] Step 1: Create model/db.php (connect).
- [ ] Step 2: Create model/UserModel.php (CRUD methods).
- [ ] Step 3: Update controllers to use UserModel.
- [ ] Step 4: SQL create DB/table.
- [ ] Step 5: Test.
