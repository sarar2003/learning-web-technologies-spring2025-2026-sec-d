# AJAX/JSON CRUD Implementation Plan Steps

## Approved Plan Summary

- Update controllers to return JSON for AJAX.
- Enhance user_list.php with JS modals/table refresh.
- AJAX-ify login/signup.
- Maintain folder structure, session storage.

## TODO Steps

- [x] Step 1: Create controller/getUsers.php ✅
- [x] Step 2: Update all controller/\*.php to JSON ✅
- [x] Step 3: AJAX user_list.php with modals ✅
- [x] Step 4: AJAX login.php, signup.php ✅
- [ ] Step 5: Update home.php (add AJAX logout).
- [ ] Step 6: Test.
- [x] Complete! Ready to demo.

Current progress: Final tweaks (home.php), then test/complete.
